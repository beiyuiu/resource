

数据库表设计 
第一类：首页显示类
#| xz_index_carousel   |首页图片轮播
#| xz_index_product    |首页产品表

第二类：后台商品管理类
#| xz_laptop           |产品表
#| xz_laptop_family    |产品类别表
#| xz_laptop_pic       |产品图表
#| xz_order            |订单表
#| xz_order_detail     |订单详细表
#| xz_receiver_address |收货地址表
#| xz_shopping_cart    |购物车表
第三类：权限管理类
#| xz_user             |用户表
#| xz_role             |角色表
#| xz_users_roles      |用户和角色关系表
#| xz_module           |模块表表
#| xz_acl              |权限表
