学子商城后台管理

模块四:商品价格更新

解决问题:用户管理
[前台用户通过注册完成添加]  xz_user
[后台管理通过超级管理添加]
xz_admin[uid,uname,upwd]
xz_admin_info[id,uid,phone,addr,sex,rdate,cuid,ctime,muid,mtime]
cuid   创建用户编号
ctime  创建时间
muid   修改用户编号
mtime  修改用户时间
last_logintime 最后一次登录时间

更新产品价格
1:data/06_product_update.php
2:product_list.html
3:product_list.js

