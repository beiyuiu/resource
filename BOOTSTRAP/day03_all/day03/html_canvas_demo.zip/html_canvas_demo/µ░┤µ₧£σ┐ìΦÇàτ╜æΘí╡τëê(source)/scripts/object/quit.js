var rotate = require( "../factory/rotate" );
var tween = require( "../lib/tween" );

exports = rotate.create("images/quit.png", 493, 311, 141, 141, 1e-5, tween.exponential.co, 500);